let birds = [];
let smoke = [];
let truckX = 500;
let harvesterX = 400;
let carX = 600;

function setup() {
  createCanvas(800, 400);

  // Inicializa pássaros
  for (let i = 0; i < 5; i++) {
    birds.push({ x: random(width), y: random(50, 120), speed: random(0.5, 1.5) });
  }

  // Inicializa fumaça
  for (let i = 0; i < 10; i++) {
    smoke.push({ x: 610 + (i % 5) * 30, y: 150 - floor(i / 5) * 10, r: 5 });
  }
}

function draw() {
  background(135, 206, 235); // céu azul

  drawSun();
  drawGrass();
  drawCity();
  drawTrees();
  drawFarmAnimals();
  updateBirds();
  updateSmoke();
  updateHarvester();
  drawFields();
  drawWorkers();
  updateTruck();
  updateCars();
}

// Sol
function drawSun() {
  fill(255, 204, 0);
  ellipse(80, 80, 60);
}

// Grama
function drawGrass() {
  fill(60, 179, 113);
  rect(0, 300, width, 100);
}

// Cidade ao fundo
function drawCity() {
  for (let i = 0; i < 5; i++) {
    fill(100);
    rect(600 + i * 30, 150 - i * 10, 30, 150 + i * 10);
    fill(50);
    for (let j = 0; j < 5; j++) {
      rect(605 + i * 30, 160 + j * 20 - i * 10, 10, 10);
    }
  }
}

// Fumaça animada
function updateSmoke() {
  fill(200);
  for (let s of smoke) {
    ellipse(s.x, s.y, s.r);
    s.y -= 0.3;
    s.r += 0.02;
    if (s.y < 100) {
      s.y = 150;
      s.r = 5;
    }
  }
}

// Árvores
function drawTrees() {
  for (let i = 0; i < 3; i++) {
    let x = 100 + i * 100;
    fill(139, 69, 19);
    rect(x, 220, 20, 80);
    fill(34, 139, 34);
    ellipse(x + 10, 200, 80);
    fill(255, 0, 0);
    ellipse(x + 30, 190, 10);
    ellipse(x - 10, 210, 10);
  }
}

// Animais
function drawFarmAnimals() {
  // Vaca
  fill(255);
  rect(250, 270, 40, 20);
  fill(0);
  rect(255, 275, 5, 5);
  fill(0);
  ellipse(245, 270, 10);

  // Cavalo
  fill(160, 82, 45);
  rect(310, 270, 40, 20);
  ellipse(305, 270, 10);
}

// Pássaros animados
function updateBirds() {
  fill(0);
  for (let b of birds) {
    arc(b.x, b.y, 20, 10, PI, 0);
    b.x += b.speed;
    if (b.x > width) b.x = -20;
  }
}

// Colheitadeira animada
function updateHarvester() {
  fill(200, 0, 0);
  rect(harvesterX, 280, 60, 30);
  fill(50);
  ellipse(harvesterX + 10, 310, 15);
  ellipse(harvesterX + 40, 310, 15);
  fill(180);
  rect(harvesterX + 60, 290, 20, 10);

  harvesterX += 0.5;
  if (harvesterX > 380) harvesterX = 380; // Limita movimento
}

// Plantações
function drawFields() {
  fill(255, 215, 0);
  for (let x = 20; x < 200; x += 20) {
    rect(x, 300, 10, -20);
  }
}

// Trabalhadores
function drawWorkers() {
  fill(0);
  ellipse(230, 280, 10);
  line(230, 285, 230, 300);
  line(230, 290, 225, 295);
  line(230, 290, 235, 295);
}

// Caminhão animado
function updateTruck() {
  fill(0, 0, 255);
  rect(truckX, 270, 50, 20);
  fill(100);
  rect(truckX + 50, 275, 30, 15);
  fill(0);
  ellipse(truckX + 10, 290, 10);
  ellipse(truckX + 40, 290, 10);

  truckX += 0.8;
  if (truckX > width + 50) truckX = -80;
}

// Carros na cidade
function updateCars() {
  fill(255, 0, 0);
  rect(carX, 320, 40, 15);
  fill(0);
  ellipse(carX + 10, 335, 10);
  ellipse(carX + 30, 335, 10);

  carX -= 1.5;
  if (carX < -50) carX = width + 50;
}
